[CmdletBinding(DefaultParameterSetName='Explicit')]
param(
    [Parameter(Mandatory,ParameterSetName='Explicit')][string]$OneDriveRoot,
    [Parameter(Mandatory,ParameterSetName='Explicit')][string[]]$ExpectedAccount,
    [Parameter(ParameterSetName='Explicit')][Parameter(ParameterSetName='Configured')][double]$FreshnessHours = 26,
    [Parameter(Mandatory,ParameterSetName='Configured')][string]$ConfigPath,
    [Parameter(ParameterSetName='Configured')][string]$RuntimeRoot,
    [Parameter(Mandatory,ParameterSetName='Library')][switch]$AsLibrary
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Get-AmmarTradingDestinationPath {
    param(
        [Parameter(Mandatory)][string]$OneDriveRoot,
        [Parameter(Mandatory)][string]$AccountNumber,
        [string]$VpsId,
        [string]$DestinationFolder
    )

    $resolvedRoot = Resolve-AmmarTradingOneDriveRoot -Path $OneDriveRoot
    $folder = if([string]::IsNullOrWhiteSpace($DestinationFolder)) { Join-Path $resolvedRoot 'amartrading' } else { [IO.Path]::GetFullPath([Environment]::ExpandEnvironmentVariables($DestinationFolder.Trim())) }
    $rootPrefix = $resolvedRoot.TrimEnd([IO.Path]::DirectorySeparatorChar,[IO.Path]::AltDirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
    if(-not $folder.StartsWith($rootPrefix, [StringComparison]::OrdinalIgnoreCase)) { throw 'The destination folder must be inside the selected OneDrive root.' }
    $accountPath = Join-Path ("Account_{0}" -f $AccountNumber) 'Baskets.csv'
    $relative = if([string]::IsNullOrWhiteSpace($VpsId)) { $accountPath } else { Join-Path ("VPS_{0}" -f $VpsId) $accountPath }
    Join-Path $folder $relative
}

function Get-AmmarTradingHeartbeatStatus {
    param(
        [Parameter(Mandatory)][string]$OneDriveRoot,
        [Parameter(Mandatory)][string]$AccountNumber,
        [string]$VpsId,
        [string]$DestinationFolder,
        [Parameter(Mandatory)][double]$FreshnessHours
    )

    $result = [ordered]@{
        AccountNumber = $AccountNumber
        VpsId = if($VpsId){$VpsId}else{'legacy-unassigned'}
        Status = 'Error'
        StatusCode = 'HeartbeatError'
        IsFresh = $false
        HeartbeatAgeHours = $null
        Message = ''
    }
    try {
        if([string]::IsNullOrWhiteSpace($AccountNumber)) { throw 'Expected account number is empty.' }
        $destination = Get-AmmarTradingDestinationPath -OneDriveRoot $OneDriveRoot -AccountNumber $AccountNumber -VpsId $VpsId -DestinationFolder $DestinationFolder
        $statusPath = Join-Path (Split-Path -Parent $destination) 'SyncStatus.json'
        if(-not (Test-Path -LiteralPath $statusPath -PathType Leaf)) {
            $result.StatusCode = 'MissingHeartbeat'
            throw 'Receiver heartbeat is missing.'
        }
        $heartbeat = Get-Content -LiteralPath $statusPath -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
        if([string]$heartbeat.AccountNumber -cne $AccountNumber) {
            $result.StatusCode = 'AccountMismatch'
            throw 'Heartbeat account does not match the expected folder account.'
        }
        if($VpsId -and [string]$heartbeat.VpsId -cne $VpsId) { $result.StatusCode = 'VpsMismatch'; throw 'Heartbeat VPS identity does not match the configured VPS.' }
        if([string]$heartbeat.Status -cne 'Success') {
            $result.StatusCode = 'PublisherError'
            throw "Heartbeat status is '$($heartbeat.Status)' instead of Success."
        }
        if([bool]$heartbeat.CloudDeliveryVerified) {
            $result.StatusCode = 'InvalidCloudClaim'
            throw 'Publisher heartbeat must not claim cloud delivery verification.'
        }

        $publishedUtc = [DateTimeOffset]::MinValue
        $styles = [Globalization.DateTimeStyles]::AssumeUniversal -bor [Globalization.DateTimeStyles]::AdjustToUniversal
        if(-not [DateTimeOffset]::TryParse([string]$heartbeat.PublishedUtc, [Globalization.CultureInfo]::InvariantCulture, $styles, [ref]$publishedUtc)) {
            $result.StatusCode = 'InvalidPublishedUtc'
            throw 'Heartbeat PublishedUtc is invalid.'
        }
        $ageHours = ([DateTimeOffset]::UtcNow - $publishedUtc).TotalHours
        $result.HeartbeatAgeHours = [Math]::Round($ageHours, 3)
        if($ageHours -lt -0.0833) {
            $result.StatusCode = 'FutureHeartbeat'
            throw 'Heartbeat PublishedUtc is more than five minutes in the future.'
        }
        if($ageHours -gt $FreshnessHours) {
            $result.StatusCode = 'StaleHeartbeat'
            throw "Heartbeat is stale: $([Math]::Round($ageHours, 2)) hours old."
        }

        $result.Status = 'Success'
        $result.StatusCode = 'Fresh'
        $result.IsFresh = $true
        $result.Message = 'Receiver heartbeat is present and fresh.'
    } catch {
        $result.Message = $_.Exception.Message
    }

    return [pscustomobject]$result
}

function Get-AmmarTradingTaskEvidence {
    $taskNames = @(
        'MoneyMachine-Baskets-To-OneDrive-Daily',
        'MoneyMachine-Baskets-To-OneDrive-StartupCatchup'
    )
    if(-not (Get-Command Get-ScheduledTask -ErrorAction SilentlyContinue) -or
       -not (Get-Command Get-ScheduledTaskInfo -ErrorAction SilentlyContinue)) {
        return [pscustomobject]@{ TaskState='Unavailable'; TaskResultCode='Unavailable' }
    }

    $evidence = [System.Collections.Generic.List[object]]::new()
    foreach($taskName in $taskNames) {
        $task = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
        if($null -eq $task) {
            $evidence.Add([pscustomobject]@{ Name=$taskName; State='Missing'; Result='NotRun' })
            continue
        }
        $taskInfo = Get-ScheduledTaskInfo -TaskName $taskName -ErrorAction SilentlyContinue
        $resultCode = if($null -eq $taskInfo) { 'Unknown' } else { [string]$taskInfo.LastTaskResult }
        $evidence.Add([pscustomobject]@{ Name=$taskName; State=[string]$task.State; Result=$resultCode })
    }

    $present = @($evidence | Where-Object State -ne 'Missing').Count
    $taskState = if($present -eq $taskNames.Count) { 'Registered' } elseif($present -gt 0) { 'Partial' } else { 'NotRegistered' }
    $resultCodes = @($evidence | ForEach-Object { '{0}:{1}' -f ([IO.Path]::GetFileName($_.Name)),$_.Result }) -join ';'
    return [pscustomobject]@{ TaskState=$taskState; TaskResultCode=$resultCodes }
}

function Get-AmmarTradingConfiguredSyncStatus {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$ConfigPath,
        [string]$RuntimeRoot,
        [double]$FreshnessHours = 26
    )

    if($FreshnessHours -le 0) { throw 'FreshnessHours must be greater than zero.' }
    if(-not (Test-Path -LiteralPath $ConfigPath -PathType Leaf)) { return @() }
    if([string]::IsNullOrWhiteSpace($RuntimeRoot)) { $RuntimeRoot = Split-Path -Parent ([IO.Path]::GetFullPath($ConfigPath)) }

    $schemaModule = Join-Path $PSScriptRoot 'MoneyMachineCsvSchemaV3.psm1'
    if(-not (Test-Path -LiteralPath $schemaModule -PathType Leaf)) { throw 'The schema status component is missing.' }
    Import-Module -Name $schemaModule -Force -ErrorAction Stop
    $setupModule = Join-Path $PSScriptRoot 'MoneyMachineSyncSetup.psm1'
    if(-not (Test-Path -LiteralPath $setupModule -PathType Leaf)) { throw 'The path status component is missing.' }
    Import-Module -Name $setupModule -ErrorAction Stop
    $taskEvidence = Get-AmmarTradingTaskEvidence
    $accounts = [System.Collections.Generic.List[object]]::new()
    foreach($configuration in @(Import-Csv -LiteralPath $ConfigPath -ErrorAction Stop)) {
        $accountNumber = ([string]$configuration.ExpectedMT4Login).Trim()
        if($accountNumber -notmatch '^\d{4,20}$') { continue }
        $configuredRoot = $null
        try {
            $configuredRoot = Resolve-AmmarTradingOneDriveRoot -Path ([string]$configuration.OneDriveRoot)
        } catch {
            $accounts.Add([pscustomobject][ordered]@{
                AccountNumber = $accountNumber
                BrokerName = ''
                SchemaVersion = ''
                SourceCsv = ''
                Destination = ''
                LocalPublished = $false
                LastWriteUtc = $null
                Freshness = 'Unknown'
                Status = 'Error'
                StatusCode = 'UntrustedOneDriveRoot'
                TaskState = [string]$taskEvidence.TaskState
                TaskResultCode = [string]$taskEvidence.TaskResultCode
                FailureReason = 'The configured OneDrive root is no longer trusted.'
            })
            continue
        }
        $vpsId = if($configuration.PSObject.Properties['VpsId']) { ([string]$configuration.VpsId).Trim() } else { '' }
        $destinationFolder = if($configuration.PSObject.Properties['DestinationFolder']) { ([string]$configuration.DestinationFolder).Trim() } else { '' }
        $destination = Get-AmmarTradingDestinationPath -OneDriveRoot $configuredRoot -AccountNumber $accountNumber -VpsId $vpsId -DestinationFolder $destinationFolder
        $heartbeat = Get-AmmarTradingHeartbeatStatus -OneDriveRoot $configuredRoot -AccountNumber $accountNumber -VpsId $vpsId -DestinationFolder $destinationFolder -FreshnessHours $FreshnessHours
        $localPublished = Test-Path -LiteralPath $destination -PathType Leaf
        $destinationItem = if($localPublished) { Get-Item -LiteralPath $destination -ErrorAction SilentlyContinue } else { $null }
        $sourceCsv = [Environment]::ExpandEnvironmentVariables(([string]$configuration.SourceCsv).Trim())
        $identity = $null
        if(Test-Path -LiteralPath $sourceCsv -PathType Leaf) {
            try { $identity = Get-AmmarTradingCsvIdentity -Path $sourceCsv } catch { $identity = $null }
        }
        $statusCode = if(-not $localPublished -and $heartbeat.StatusCode -ceq 'Fresh') { 'DestinationMissing' } else { [string]$heartbeat.StatusCode }
        $status = if($localPublished -and $heartbeat.Status -ceq 'Success') { 'Success' } else { 'Error' }
        $accounts.Add([pscustomobject][ordered]@{
            VpsId = if($vpsId){$vpsId}else{'legacy-unassigned'}
            VpsName = if($configuration.PSObject.Properties['VpsName']) { [string]$configuration.VpsName } else { '' }
            AccountNumber = $accountNumber
            AccountKey = ('{0}|{1}' -f $(if($vpsId){$vpsId}else{'legacy-unassigned'}),$accountNumber)
            BrokerName = if($null -eq $identity) { '' } else { [string]$identity.BrokerName }
            SchemaVersion = if($null -eq $identity) { '' } else { [string]$identity.SchemaVersion }
            SourceCsv = $sourceCsv
            Destination = $destination
            DestinationFolder = if([string]::IsNullOrWhiteSpace($destinationFolder)) { Join-Path $configuredRoot 'amartrading' } else { $destinationFolder }
            LocalPublished = $localPublished
            LastWriteUtc = if($null -eq $destinationItem) { $null } else { $destinationItem.LastWriteTimeUtc.ToString('o') }
            Freshness = if([bool]$heartbeat.IsFresh) { 'Fresh' } elseif($heartbeat.StatusCode -ceq 'StaleHeartbeat') { 'Stale' } else { 'Unknown' }
            Status = $status
            StatusCode = $statusCode
            TaskState = [string]$taskEvidence.TaskState
            TaskResultCode = [string]$taskEvidence.TaskResultCode
            FailureReason = if($status -ceq 'Success') { '' } else { [string]$heartbeat.Message }
        })
    }
    return @($accounts)
}

if($AsLibrary) { return }

if($FreshnessHours -le 0) { throw 'FreshnessHours must be greater than zero.' }
if($PSCmdlet.ParameterSetName -ceq 'Configured') {
    $configuredResults = @(Get-AmmarTradingConfiguredSyncStatus -ConfigPath $ConfigPath -RuntimeRoot $RuntimeRoot -FreshnessHours $FreshnessHours)
    [pscustomobject]@{ Accounts=$configuredResults } | ConvertTo-Json -Depth 6
    if(@($configuredResults | Where-Object Status -eq 'Error').Count -gt 0) { exit 1 }
    exit 0
}

if(-not (Test-Path -LiteralPath $OneDriveRoot -PathType Container)) { throw "OneDrive root not found: $OneDriveRoot" }
$results = [System.Collections.Generic.List[object]]::new()
foreach($account in $ExpectedAccount) {
    $results.Add((Get-AmmarTradingHeartbeatStatus -OneDriveRoot $OneDriveRoot -AccountNumber ([string]$account).Trim() -FreshnessHours $FreshnessHours))
}
@($results | Select-Object AccountNumber,Status,IsFresh,HeartbeatAgeHours,Message) | ConvertTo-Json -Depth 4
if(@($results | Where-Object Status -eq 'Error').Count -gt 0) { exit 1 }
exit 0

# SIG # Begin signature block
# MIIHYAYJKoZIhvcNAQcCoIIHUTCCB00CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCA5zi9k7SJQVQqv
# JYSx+4YNRrJnmDFGB7A0UxD6i870pKCCBEUwggRBMIICqaADAgECAhBw3+fRlCq+
# uUIlH/KQwoSNMA0GCSqGSIb3DQEBCwUAMCsxKTAnBgNVBAMMIEFtYXJUcmFkaW5n
# IFRlc3QgUm9vdCAyMDI2LTA5LTEzMB4XDTI2MDkxMzIwMzYzOVoXDTI3MDkxMzIw
# NDYzOFowJTEjMCEGA1UEAwwaQW1hclRyYWRpbmcgVGVzdCBQdWJsaXNoZXIwggGi
# MA0GCSqGSIb3DQEBAQUAA4IBjwAwggGKAoIBgQCzlDHdYjciWmJlVk+qaO0AKOWR
# ptpN7jDDP4xTVYk+sZsX3iJv3nSrxPyV8xqxHOQbyz82DCDF3szFAp9OUYBiLIUx
# jLIzPFCx+w2VYN9OmjtpgB16JUkOF6rg01ifm4ChZaVkRPTBQw/u3bZaM00LxiRg
# XBTiCVDYqg1FTep5AStzgxLImhb8IehyKTSxSWj/9+02ISbZzZQ+fGgJrf9BnKDL
# 4xrdxT37W2jwVutsr7mWa70SU47vK4+T0D5p4pVKZE1K8ORp/cwFrNCrtArouJ6a
# eJF5ywcbugaxayWzOkHPNZegynI0ENnDpCkGBJTEhLDXdMpxtxCSX2Fa/2YShKMd
# vbn2yXmJlZY4iDCbu97tB36xtdH3ChfPwgQP0yVH6HBjhCR2qjkXTvpu3rxH0hRN
# Ny1hgzsN24HhfGqY/UKdlP2wfU9Fnnoq55HZzHz4hGvOdEa+R1X9dJMG8ZE/Biki
# twL+Cq2oUM1dteR1WaFV59fUIgNlmWhZjeAb+D0CAwEAAaNnMGUwDgYDVR0PAQH/
# BAQDAgeAMBMGA1UdJQQMMAoGCCsGAQUFBwMDMB8GA1UdIwQYMBaAFDZt/TgYFsoB
# IkAP0dhOyE/nwN5ZMB0GA1UdDgQWBBSNa1yu9mqNiT9QIePEjr59vlN/ETANBgkq
# hkiG9w0BAQsFAAOCAYEAIvLWlo/Oi7eh4LZQOgiWcYroQJzv27q3w9fIiTUKsn2+
# Y+eKd4jCwkK70Yfh2Pxkjv4BgZ2Awg06+kigubm/2Ad3JH2UVrPAQ0NrNpc5yjLb
# YGNDUYDKShca6r6gQoS3daI8ZnyF79OapaUqXVL+u7RrGMOnShBkIccOJnSKnZdD
# yzIcmSl55cUo6nMRPGCdwCf5zEA4GuozmrBPtbIl06dPYClxn9gkmn41tAbBv37t
# ENUmzBcj05GB+9/4m1mqSnC/CFpytH1BFQ2hG0U86oVN52GUk3Si5sa/03Bjn0QH
# c0BXKN+EAoGqg4dCCUbA+HNlREDLw7uW+McuJfpuJd7cltDMpMp3p0CxNc8uelOd
# mqeJj/WOVC8uJmcYNcr+i9aBXoPV2dhY9O87G9EJJaCx5ZK7SzqbHNl/zWXdMTrs
# tudDX/6xq8Pq1mcfrvAahzHNHaQcdwvPgxJK1hQKOFXJuWjbWujab9YLd1G8eeNw
# 63yHxso9W3q0AVa+daUTMYICcTCCAm0CAQEwPzArMSkwJwYDVQQDDCBBbWFyVHJh
# ZGluZyBUZXN0IFJvb3QgMjAyNi0wOS0xMwIQcN/n0ZQqvrlCJR/ykMKEjTANBglg
# hkgBZQMEAgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3
# DQEJAzEMBgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEV
# MC8GCSqGSIb3DQEJBDEiBCBlkOqL2s+7R/rp4nne+hCgtliHv+sSZ8c3JptkvNct
# +DANBgkqhkiG9w0BAQEFAASCAYBPpYl+yC56DJ9yB6S4ie7tEFby8hTsdNmxTQQI
# 1M7k0X0m2sEpN2Sv8CGFQKmjhHk1fwSPnelHXzzJJo/uVYksxs+fCng8dOIBUXfz
# zKkr4qBNWsTYJptSY2TCGokbWVsapB8HtierVnO478GAAKek8Q3/5xAK+ZAcdBIT
# W9Y7jGNF1Dtjg6k3ZtSAe8VG3Fe30V5NroMeGdL5tytUMbsw/lqoJ0MLY4pLcRYb
# QxfXlM86nhKWFaHoeQ0/mL9EissSz+rVX/OKIPl0Zs+of1bbMn4VIZaiU6y7obwK
# hT1z/xox/s/3CB1ZcmJDtAVlxFwEBDVLSTD0rHURHqBou3OHiteb8yjQNSfgSxh1
# LDpRRAKwj89/4uSvv3RN54568EhPyc4iTSHLmKnRCMFqI3Z+TStjgy/4WOtx1VBN
# f2hQM5Mc3ElwuvDhMdP5O7Ic5Tg9PMJbMYm2MtvUJP8CXu7ZvKEjI3Ryd/RwocQu
# abL5r18/1aaqyPPnjNwoPI+Uqcw=
# SIG # End signature block
