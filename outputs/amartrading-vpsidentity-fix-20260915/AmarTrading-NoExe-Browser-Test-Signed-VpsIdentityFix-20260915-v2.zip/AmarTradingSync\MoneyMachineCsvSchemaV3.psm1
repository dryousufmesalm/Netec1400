Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

Add-Type -AssemblyName Microsoft.VisualBasic

$script:SchemaV3Columns = @(
    'AccountNumber','BrokerName','BasketID','Symbol','SymbolNormalized','Timeframe','StartTime','EndTime','DurationSeconds',
    'Direction','OrdersCount','TotalLots','FixedLots','MaxOrdersConcurrent','MaxTotalLots','MaxFloatingDrawdownAbs','MaxFloatingProfit',
    'ClosePL','CloseReason','OutcomeClass','SpreadAtEntry','EquityAtEntry','HeadroomAtEntry','MinHeadroom','TimesNearKill',
    'ExposureBlocks','PipsStep','TakeProfit','KillEquityLevel','MaxOrdersInBasket','MaxTotalLotsInBasket','EquityAtExit','BalanceAfter',
    'TradeDate','RunID','RunStartTime','RunStartBalance','EAName','EAVersion','Magic','PointsPerPip','Tral','TralStart','MaxSpread',
    'TimeStart','TimeEnd','OpenTime','NewBasketDelaySeconds','SpeedEA','UseBasketTrailingTP','TrailingStart','TrailingStep',
    'KillSwitchEnable','KillCooldownMinutes','RegimeEnable','RegimeAction','RegimeADXPeriod','RegimeADXLevel','RegimeADXBars',
    'RegimeRangeBars','RegimeRecoveryBars','EnableTradingDaysFilter','TradeMonday','TradeTuesday','TradeWednesday','TradeThursday',
    'TradeFriday','EnableRecoveryStepUp','RecoveryWaitMinutes','RecoveryMaxTotalLotsInBasket','CsvSchemaVersion'
)
$script:SchemaV2Columns = @($script:SchemaV3Columns[0..33]) + @('CsvSchemaVersion')
$script:IdentityColumns = @('AccountNumber','BrokerName','CsvSchemaVersion','EAVersion')

$script:IntegerFields = @(
    'BasketID','Timeframe','DurationSeconds','OrdersCount','MaxOrdersConcurrent','TimesNearKill','ExposureBlocks','PipsStep',
    'MaxOrdersInBasket','Magic','PointsPerPip','Tral','TralStart','MaxSpread','TimeStart','TimeEnd','OpenTime',
    'NewBasketDelaySeconds','SpeedEA','KillCooldownMinutes','RegimeAction','RegimeADXPeriod','RegimeADXBars','RegimeRangeBars',
    'RegimeRecoveryBars','RecoveryWaitMinutes','CsvSchemaVersion'
)
$script:DecimalFields = @(
    'TotalLots','FixedLots','MaxTotalLots','MaxFloatingDrawdownAbs','MaxFloatingProfit','ClosePL','SpreadAtEntry','EquityAtEntry',
    'HeadroomAtEntry','MinHeadroom','TakeProfit','KillEquityLevel','MaxTotalLotsInBasket','EquityAtExit','BalanceAfter',
    'RunStartBalance','TrailingStart','TrailingStep','RegimeADXLevel','RecoveryMaxTotalLotsInBasket'
)
$script:BooleanFields = @(
    'UseBasketTrailingTP','KillSwitchEnable','RegimeEnable','EnableTradingDaysFilter','TradeMonday','TradeTuesday',
    'TradeWednesday','TradeThursday','TradeFriday','EnableRecoveryStepUp'
)
$script:TimestampFields = @('StartTime','EndTime','RunStartTime')
$script:DateFields = @('TradeDate')
$script:TextFields = @(
    'AccountNumber','BrokerName','Symbol','SymbolNormalized','Direction','CloseReason','OutcomeClass','RunID','EAName','EAVersion'
)
$script:ControlledValues = @{
    Direction = @('BUY','SELL')
    CloseReason = @('TP','KILL','OTHER')
    OutcomeClass = @('KILL','NORMAL_PROFIT','RECOVERY_PROFIT','OTHER')
    RegimeAction = @('0','1')
}

$script:Culture = [Globalization.CultureInfo]::InvariantCulture
$script:IntegerStyle = [Globalization.NumberStyles]::AllowLeadingSign
$script:DecimalStyle = [Globalization.NumberStyles]([Globalization.NumberStyles]::AllowLeadingSign -bor [Globalization.NumberStyles]::AllowDecimalPoint)

$classifiedFields = @($script:IntegerFields + $script:DecimalFields + $script:BooleanFields + $script:TimestampFields + $script:DateFields + $script:TextFields)
if($classifiedFields.Count -ne $script:SchemaV3Columns.Count) { throw 'Schema-v3 field classification does not contain exactly 71 entries.' }
if(@($classifiedFields | Group-Object | Where-Object Count -ne 1).Count -gt 0) { throw 'Schema-v3 field classification contains duplicate entries.' }
if(@($script:SchemaV3Columns | Where-Object { $_ -notin $classifiedFields }).Count -gt 0) { throw 'Schema-v3 field classification is incomplete.' }

function Get-MoneyMachineSchemaV3Columns {
    [CmdletBinding()]
    param()
    return @($script:SchemaV3Columns)
}

function Test-ExactCsvHeader {
    param([object[]]$Header,[string[]]$Expected)

    if($Header.Count -ne $Expected.Count) { return $false }
    for($index = 0; $index -lt $Expected.Count; $index++) {
        $actual = ([string]$Header[$index]).TrimStart([char]0xFEFF)
        if($actual -cne $Expected[$index]) { return $false }
    }
    return $true
}

function Get-AmmarTradingImmediateIdentity {
    param([Parameter(Mandatory)][string]$BasketsPath)

    $identityPath = Join-Path ([IO.Path]::GetDirectoryName($BasketsPath)) 'AGOLD___Identity.csv'
    if(-not (Test-Path -LiteralPath $identityPath -PathType Leaf)) { return $null }
    $identityFile = Get-Item -LiteralPath $identityPath -ErrorAction Stop
    if(($identityFile.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0 -or $identityFile.Length -le 0 -or $identityFile.Length -gt 4096) {
        return $null
    }

    $parser = $null
    try {
        $parser = New-Object Microsoft.VisualBasic.FileIO.TextFieldParser($identityPath, [Text.Encoding]::UTF8, $true)
        $parser.TextFieldType = [Microsoft.VisualBasic.FileIO.FieldType]::Delimited
        $parser.SetDelimiters(',')
        $parser.HasFieldsEnclosedInQuotes = $true
        $parser.TrimWhiteSpace = $false
        if($parser.EndOfData) { return $null }
        $header = @($parser.ReadFields())
        if(-not (Test-ExactCsvHeader -Header $header -Expected $script:IdentityColumns) -or $parser.EndOfData) { return $null }
        $fields = @($parser.ReadFields())
        if($fields.Count -ne $script:IdentityColumns.Count -or -not $parser.EndOfData) { return $null }
        if([string]$fields[0] -notmatch '^\d+$' -or
           [string]::IsNullOrWhiteSpace([string]$fields[1]) -or
           [string]$fields[2] -cne '3' -or
           [string]$fields[3] -cne '3.00') { return $null }
        return [pscustomobject]@{
            AccountNumber = [string]$fields[0]
            BrokerName = [string]$fields[1]
            SchemaVersion = [string]$fields[2]
        }
    } catch {
        return $null
    } finally {
        if($null -ne $parser) {
            $parser.Close()
            $parser.Dispose()
        }
    }
}

function Get-AmmarTradingCsvIdentity {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$Path)

    if(-not (Test-Path -LiteralPath $Path -PathType Leaf)) { throw "CSV file not found: $Path" }

    $accountNumber = $null
    $brokerName = $null
    $schemaVersion = $null
    $status = 'MalformedCsv'
    $parser = $null
    try {
        $parser = New-Object Microsoft.VisualBasic.FileIO.TextFieldParser($Path, [Text.Encoding]::UTF8, $true)
        $parser.TextFieldType = [Microsoft.VisualBasic.FileIO.FieldType]::Delimited
        $parser.SetDelimiters(',')
        $parser.HasFieldsEnclosedInQuotes = $true
        $parser.TrimWhiteSpace = $false

        if(-not $parser.EndOfData) {
            $header = @($parser.ReadFields())
            $isSchemaV3Header = Test-ExactCsvHeader -Header $header -Expected $script:SchemaV3Columns
            $isSchemaV2Header = Test-ExactCsvHeader -Header $header -Expected $script:SchemaV2Columns
            if($isSchemaV3Header -or $isSchemaV2Header) {
                $schemaVersion = if($isSchemaV2Header) { '2' } else { '3' }
                if($parser.EndOfData) {
                    $status = if($isSchemaV2Header) { 'SchemaV2' } else { 'HeaderOnly' }
                } else {
                    $fields = @($parser.ReadFields())
                    if($fields.Count -eq $header.Count) {
                        $accountNumber = [string]$fields[0]
                        $brokerName = [string]$fields[1]
                        $schemaVersion = [string]$fields[$fields.Count - 1]
                        if($isSchemaV2Header -or $schemaVersion -ceq '2') {
                            $status = 'SchemaV2'
                        } elseif($schemaVersion -ceq '3' -and
                            $accountNumber -match '^\d+$' -and
                            -not [string]::IsNullOrWhiteSpace($brokerName)) {
                            $status = 'Ready'
                        }
                    }
                }
            }
        }
    } catch {
        $status = 'MalformedCsv'
    } finally {
        if($null -ne $parser) {
            $parser.Close()
            $parser.Dispose()
        }
    }

    if($status -ceq 'HeaderOnly') {
        $immediateIdentity = Get-AmmarTradingImmediateIdentity -BasketsPath $Path
        if($null -ne $immediateIdentity) {
            $accountNumber = $immediateIdentity.AccountNumber
            $brokerName = $immediateIdentity.BrokerName
            $schemaVersion = $immediateIdentity.SchemaVersion
            $status = 'Ready'
        }
    }

    return [pscustomobject][ordered]@{
        AccountNumber = $accountNumber
        BrokerName = $brokerName
        SchemaVersion = $schemaVersion
        Status = $status
    }
}

function Test-InvariantInteger {
    param([string]$Value)
    $parsed = [int64]0
    return [int64]::TryParse($Value, $script:IntegerStyle, $script:Culture, [ref]$parsed)
}

function Test-InvariantDecimal {
    param([string]$Value)
    $parsed = [decimal]0
    return [decimal]::TryParse($Value, $script:DecimalStyle, $script:Culture, [ref]$parsed)
}

function Convert-ExactTimestamp {
    param([string]$Value, [string]$Field, [int]$RowNumber)
    $parsed = [datetime]::MinValue
    if(-not [datetime]::TryParseExact($Value, 'yyyy-MM-dd HH:mm:ss', $script:Culture, [Globalization.DateTimeStyles]::None, [ref]$parsed)) {
        throw "Row $RowNumber field '$Field' must use yyyy-MM-dd HH:mm:ss."
    }
    return $parsed
}

function Convert-ExactDate {
    param([string]$Value, [string]$Field, [int]$RowNumber)
    $parsed = [datetime]::MinValue
    if(-not [datetime]::TryParseExact($Value, 'yyyy-MM-dd', $script:Culture, [Globalization.DateTimeStyles]::None, [ref]$parsed)) {
        throw "Row $RowNumber field '$Field' must use yyyy-MM-dd."
    }
    return $parsed
}

function Read-MoneyMachineBasketsCsv {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter(Mandatory)][string]$ExpectedLogin
    )

    if(-not (Test-Path -LiteralPath $Path -PathType Leaf)) { throw "CSV file not found: $Path" }
    if([string]::IsNullOrWhiteSpace($ExpectedLogin)) { throw 'ExpectedLogin is required.' }

    $parser = [Microsoft.VisualBasic.FileIO.TextFieldParser]::new($Path, [Text.Encoding]::UTF8, $true)
    $parser.TextFieldType = [Microsoft.VisualBasic.FileIO.FieldType]::Delimited
    $parser.SetDelimiters(',')
    $parser.HasFieldsEnclosedInQuotes = $true
    $parser.TrimWhiteSpace = $false
    $rows = [System.Collections.Generic.List[object]]::new()
    $keys = [System.Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
    try {
        if($parser.EndOfData) { throw 'CSV header is empty.' }
        $header = @($parser.ReadFields())
        if($header.Count -ne $script:SchemaV3Columns.Count) { throw "CSV header has $($header.Count) columns; expected $($script:SchemaV3Columns.Count)." }
        for($index = 0; $index -lt $script:SchemaV3Columns.Count; $index++) {
            $actual = ([string]$header[$index]).TrimStart([char]0xFEFF)
            if($actual -cne $script:SchemaV3Columns[$index]) { throw "CSV header column $($index + 1) is '$actual'; expected '$($script:SchemaV3Columns[$index])'." }
        }

        $rowNumber = 1
        while(-not $parser.EndOfData) {
            $rowNumber++
            try { $fields = @($parser.ReadFields()) }
            catch [Microsoft.VisualBasic.FileIO.MalformedLineException] { throw "Row $rowNumber is malformed CSV: $($_.Exception.Message)" }
            if($fields.Count -ne $script:SchemaV3Columns.Count) { throw "Row $rowNumber has $($fields.Count) fields; expected $($script:SchemaV3Columns.Count)." }

            $values = [ordered]@{}
            for($index = 0; $index -lt $script:SchemaV3Columns.Count; $index++) { $values[$script:SchemaV3Columns[$index]] = [string]$fields[$index] }
            $row = [pscustomobject]$values

            foreach($field in @('AccountNumber','RunID','BasketID')) {
                if([string]::IsNullOrWhiteSpace([string]$row.$field)) { throw "Row $rowNumber field '$field' is required." }
            }
            if($row.AccountNumber -cne $ExpectedLogin) { throw "Row $rowNumber field 'AccountNumber' value '$($row.AccountNumber)' does not match ExpectedMT4Login '$ExpectedLogin'." }

            foreach($field in $script:IntegerFields) {
                if($field -eq 'MaxOrdersInBasket' -and $row.$field -eq '') { $row.$field = '0' }
                if(-not (Test-InvariantInteger -Value $row.$field)) { throw "Row $rowNumber field '$field' must be an invariant integer." }
            }
            foreach($field in $script:DecimalFields) {
                if(-not (Test-InvariantDecimal -Value $row.$field)) { throw "Row $rowNumber field '$field' must be an invariant decimal." }
            }
            foreach($field in $script:BooleanFields) {
                if($row.$field -cnotin @('0','1')) { throw "Row $rowNumber field '$field' must be 0 or 1." }
            }
            foreach($field in $script:ControlledValues.Keys) {
                if($row.$field -cnotin $script:ControlledValues[$field]) { throw "Row $rowNumber field '$field' has unsupported value '$($row.$field)'." }
            }
            if($row.CsvSchemaVersion -cne '3') { throw "Row $rowNumber field 'CsvSchemaVersion' must be 3." }

            $startTime = Convert-ExactTimestamp -Value $row.StartTime -Field 'StartTime' -RowNumber $rowNumber
            $endTime = Convert-ExactTimestamp -Value $row.EndTime -Field 'EndTime' -RowNumber $rowNumber
            [void](Convert-ExactTimestamp -Value $row.RunStartTime -Field 'RunStartTime' -RowNumber $rowNumber)
            $tradeDate = Convert-ExactDate -Value $row.TradeDate -Field 'TradeDate' -RowNumber $rowNumber
            if($endTime -lt $startTime) { throw "Row $rowNumber field 'EndTime' precedes StartTime." }
            $duration = [int64]$row.DurationSeconds
            if([int64]($endTime - $startTime).TotalSeconds -ne $duration) { throw "Row $rowNumber field 'DurationSeconds' does not match StartTime and EndTime." }
            if($tradeDate -ne $startTime.Date) { throw "Row $rowNumber field 'TradeDate' does not match StartTime." }

            $key = '{0}|{1}|{2}' -f $row.AccountNumber,$row.RunID,$row.BasketID
            if(-not $keys.Add($key)) { throw "Row $rowNumber has duplicate basket key '$key'." }
            $rows.Add($row)
        }
    } finally {
        $parser.Close()
        $parser.Dispose()
    }

    return [pscustomobject]@{ Rows=@($rows); RowCount=$rows.Count; Header=($script:SchemaV3Columns -join ',') }
}

Export-ModuleMember -Function Get-MoneyMachineSchemaV3Columns,Get-AmmarTradingCsvIdentity,Read-MoneyMachineBasketsCsv

# SIG # Begin signature block
# MIIHYAYJKoZIhvcNAQcCoIIHUTCCB00CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDJZhaN3jknexFx
# KEgCmwhHPYcgozY7hH5pGwbSafLFV6CCBEUwggRBMIICqaADAgECAhBw3+fRlCq+
# uUIlH/KQwoSNMA0GCSqGSIb3DQEBCwUAMCsxKTAnBgNVBAMMIEFtYXJUcmFkaW5n
# IFRlc3QgUm9vdCAyMDI2LTA5LTEzMB4XDTI2MDkxMzIwMzYzOVoXDTI3MDkxMzIw
# NDYzOFowJTEjMCEGA1UEAwwaQW1hclRyYWRpbmcgVGVzdCBQdWJsaXNoZXIwggGi
# MA0GCSqGSIb3DQEBAQUAA4IBjwAwggGKAoIBgQCzlDHdYjciWmJlVk+qaO0AKOWR
# ptpN7jDDP4xTVYk+sZsX3iJv3nSrxPyV8xqxHOQbyz82DCDF3szFAp9OUYBiLIUx
# jLIzPFCx+w2VYN9OmjtpgB16JUkOF6rg01ifm4ChZaVkRPTBQw/u3bZaM00LxiRg
# XBTiCVDYqg1FTep5AStzgxLImhb8IehyKTSxSWj/9+02ISbZzZQ+fGgJrf9BnKDL
# 4xrdxT37W2jwVutsr7mWa70SU47vK4+T0D5p4pVKZE1K8ORp/cwFrNCrtArouJ6a
# eJF5ywcbugaxayWzOkHPNZegynI0ENnDpCkGBJTEhLDXdMpxtxCSX2Fa/2YShKMd
# vbn2yXmJlZY4iDCbu97tB36xtdH3ChfPwgQP0yVH6HBjhCR2qjkXTvpu3rxH0hRN
# Ny1hgzsN24HhfGqY/UKdlP2wfU9Fnnoq55HZzHz4hGvOdEa+R1X9dJMG8ZE/Biki
# twL+Cq2oUM1dteR1WaFV59fUIgNlmWhZjeAb+D0CAwEAAaNnMGUwDgYDVR0PAQH/
# BAQDAgeAMBMGA1UdJQQMMAoGCCsGAQUFBwMDMB8GA1UdIwQYMBaAFDZt/TgYFsoB
# IkAP0dhOyE/nwN5ZMB0GA1UdDgQWBBSNa1yu9mqNiT9QIePEjr59vlN/ETANBgkq
# hkiG9w0BAQsFAAOCAYEAIvLWlo/Oi7eh4LZQOgiWcYroQJzv27q3w9fIiTUKsn2+
# Y+eKd4jCwkK70Yfh2Pxkjv4BgZ2Awg06+kigubm/2Ad3JH2UVrPAQ0NrNpc5yjLb
# YGNDUYDKShca6r6gQoS3daI8ZnyF79OapaUqXVL+u7RrGMOnShBkIccOJnSKnZdD
# yzIcmSl55cUo6nMRPGCdwCf5zEA4GuozmrBPtbIl06dPYClxn9gkmn41tAbBv37t
# ENUmzBcj05GB+9/4m1mqSnC/CFpytH1BFQ2hG0U86oVN52GUk3Si5sa/03Bjn0QH
# c0BXKN+EAoGqg4dCCUbA+HNlREDLw7uW+McuJfpuJd7cltDMpMp3p0CxNc8uelOd
# mqeJj/WOVC8uJmcYNcr+i9aBXoPV2dhY9O87G9EJJaCx5ZK7SzqbHNl/zWXdMTrs
# tudDX/6xq8Pq1mcfrvAahzHNHaQcdwvPgxJK1hQKOFXJuWjbWujab9YLd1G8eeNw
# 63yHxso9W3q0AVa+daUTMYICcTCCAm0CAQEwPzArMSkwJwYDVQQDDCBBbWFyVHJh
# ZGluZyBUZXN0IFJvb3QgMjAyNi0wOS0xMwIQcN/n0ZQqvrlCJR/ykMKEjTANBglg
# hkgBZQMEAgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3
# DQEJAzEMBgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEV
# MC8GCSqGSIb3DQEJBDEiBCBoVGxSoeX+s0DME5cKpy++zBZ6Br87IDGhhALYM/Wl
# bTANBgkqhkiG9w0BAQEFAASCAYBkpjSiGdsClA0bvrxC7L/zy42zkg4HAejBBLNP
# MoH2Qy2XH/PM4ty32LtP1Hs9EcC3K7JbN4ABn7PAvsnmg8Ems2YpeQIFk5rKC4op
# yTKb+doL6M/3LirvWj5lvSe4jGLv+F1YVJwdQvgnAO0gX+8J7RFk+qRFlyGVBDBZ
# Qve2ENb2vZLmtqyu5pPvO37L1YU3c/+zhTfRq9wLeKQao2P46SL6jhO/K6qliiKw
# 119Vvay6IBD38ZG0Xr0Qf4bqtzfdHgUwi1uSchIFhSOT+8xHotmoGIvtqVKCtRki
# 1/i8STTAnL4PhAq3C1kvJLoa3ohXzi4YSFgdgLFd5rdZmv1WOzq3Li8riKbkPIep
# 3zjaM7NGyJq2OQ3PXN+ieu8VffuRHfUpYm3zEZJxCgo+YubZ2SmCpNOu06wpF+Mx
# 8v9MP1jDSpTW4cheyDvnPf/bze0/dFXF0CfvyarNtyaf0+xG6cOQ4Cuu284C0vzN
# IUJKZvoHiHm9mFiGPzilhxT3KTs=
# SIG # End signature block
