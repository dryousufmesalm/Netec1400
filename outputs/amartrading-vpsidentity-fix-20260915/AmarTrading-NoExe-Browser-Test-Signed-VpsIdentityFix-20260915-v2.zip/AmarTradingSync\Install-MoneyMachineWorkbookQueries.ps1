[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$WorkbookPath,
    [string]$PowerQueryRoot,
    [Parameter(Mandatory)][string]$OneDriveRoot,
    [switch]$ResetRootToPlaceholder
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$ScriptRoot = Split-Path -Parent $PSCommandPath
if([string]::IsNullOrWhiteSpace($PowerQueryRoot)) { $PowerQueryRoot = Join-Path $ScriptRoot 'PowerQuery' }

$resolvedWorkbook = (Resolve-Path -LiteralPath $WorkbookPath).Path
$resolvedQueryRoot = (Resolve-Path -LiteralPath $PowerQueryRoot).Path
if(-not (Test-Path -LiteralPath $OneDriveRoot -PathType Container)) { throw "OneDrive root not found: $OneDriveRoot" }

$queryFiles = [ordered]@{
    # File names retain the product-family prefix. Workbook query names are
    # canonical AmarTrading_* names and must match the OLE DB query targets.
    AmarTrading_Baskets = Join-Path $resolvedQueryRoot 'MoneyMachine_Baskets.m'
    AmarTrading_SyncStatus = Join-Path $resolvedQueryRoot 'MoneyMachine_SyncStatus.m'
}
foreach($path in $queryFiles.Values) {
    if(-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw "Power Query source not found: $path" }
}

if(-not ('MoneyMachineNativeWindow' -as [type])) {
    Add-Type @'
using System;
using System.Runtime.InteropServices;
public static class MoneyMachineNativeWindow {
    [DllImport("user32.dll")]
    public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId);
}
'@
}

function Remove-WorkbookAbsolutePathMetadata {
    param([Parameter(Mandatory)][string]$Path)
    Add-Type -AssemblyName System.IO.Compression
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $archive = [IO.Compression.ZipFile]::Open($Path, [IO.Compression.ZipArchiveMode]::Update)
    try {
        $entry = $archive.GetEntry('xl/workbook.xml')
        if(-not $entry) { throw 'Workbook package is missing xl/workbook.xml.' }
        $reader = New-Object IO.StreamReader($entry.Open())
        try { $xml = $reader.ReadToEnd() } finally { $reader.Dispose() }
        $pattern = '<mc:AlternateContent[^>]*>\s*<mc:Choice[^>]*>\s*<x15ac:absPath[^>]*/>\s*</mc:Choice>\s*</mc:AlternateContent>'
        $cleanXml = [regex]::Replace($xml, $pattern, '', [Text.RegularExpressions.RegexOptions]::Singleline)
        if($cleanXml -eq $xml -and $xml -match 'x15ac:absPath') { throw 'Could not remove workbook absolute-path metadata.' }
        if($cleanXml -ne $xml) {
            $entry.Delete()
            $newEntry = $archive.CreateEntry('xl/workbook.xml', [IO.Compression.CompressionLevel]::Optimal)
            $writer = New-Object IO.StreamWriter($newEntry.Open(), (New-Object Text.UTF8Encoding($false)))
            try { $writer.Write($cleanXml) } finally { $writer.Dispose() }
        }
    } finally { $archive.Dispose() }
}

function Remove-AmarTradingQueryConnections {
    param([Parameter(Mandatory)]$Workbook)
    # Connections survive ListObject deletion in some Excel builds.  Delete only
    # the six possible legacy/canonical query targets before recreating the two
    # required tables, leaving unrelated workbook connections untouched.
    $queryNames = @(
        'MoneyMachine_Baskets','MoneyMachine_SyncStatus',
        'AmarTrading_Baskets','AmarTrading_SyncStatus',
        'amartrading_baskets','amartrading_syncstatus'
    )
    for($index = $Workbook.Connections.Count; $index -ge 1; $index--) {
        $connection = $Workbook.Connections.Item($index)
        $connectionText = ''
        $commandText = ''
        try { $connectionText = [string]$connection.OLEDBConnection.Connection } catch { }
        try { $commandText = [string]$connection.OLEDBConnection.CommandText } catch { }
        if($queryNames | Where-Object { $connectionText -match [regex]::Escape("Location=$_") -or $commandText -match [regex]::Escape("[$_]") }) {
            $connection.Delete()
        }
    }
}

$excel = New-Object -ComObject Excel.Application
$workbook = $null
$excelProcessId = [uint32]0
$workbookSaved = $false
try {
    $excel.Visible = $false
    $excel.DisplayAlerts = $false
    [void][MoneyMachineNativeWindow]::GetWindowThreadProcessId([IntPtr]$excel.Hwnd, [ref]$excelProcessId)
    $workbook = $excel.Workbooks.Open($resolvedWorkbook)

    $formulaSnapshot = [System.Collections.Generic.List[object]]::new()
    foreach($sheet in @($workbook.Worksheets)) {
        try {
            $formulaCells = $sheet.UsedRange.SpecialCells(-4123)
            foreach($cell in @($formulaCells.Cells)) { $formulaSnapshot.Add([pscustomobject]@{ Sheet=$sheet.Name; Address=$cell.Address(); Formula=$cell.Formula2 }) }
        } catch { }
    }

    $setupSheet = $workbook.Worksheets.Item('Power Query Setup')
    $setupSheet.Range('B4').Value2 = $OneDriveRoot
    try { $workbook.Names.Item('OneDriveRoot').Delete() } catch { }
    [void]$workbook.Names.Add('OneDriveRoot', "='Power Query Setup'!`$B`$4")

    # Remove both the canonical names and the retired aliases so a stale query
    # cannot remain reachable from an old table connection.
    for($index = $workbook.Queries.Count; $index -ge 1; $index--) {
        $existingQuery = $workbook.Queries.Item($index)
        if($existingQuery.Name -match '^(MoneyMachine|AmarTrading)_(Baskets|SyncStatus)$') {
            $existingQuery.Delete()
        }
    }
    foreach($queryName in $queryFiles.Keys) {
        [void]$workbook.Queries.Add($queryName, (Get-Content -LiteralPath $queryFiles[$queryName] -Raw))
    }

    try { $statusSheet = $workbook.Worksheets.Item('Sync Status') }
    catch {
        $statusSheet = $workbook.Worksheets.Add()
        $statusSheet.Name = 'Sync Status'
    }
    $targets = [ordered]@{
        AmarTrading_Baskets = [pscustomobject]@{ Sheet=$workbook.Worksheets.Item('Basket Data'); Table='BasketDataTable' }
        AmarTrading_SyncStatus = [pscustomobject]@{ Sheet=$statusSheet; Table='SyncStatusTable' }
    }
    Remove-AmarTradingQueryConnections -Workbook $workbook
    $connectionTemplate = 'OLEDB;Provider=Microsoft.Mashup.OleDb.1;Data Source=$Workbook$;Location={0};Extended Properties=""'
    foreach($queryName in $targets.Keys) {
        $target = $targets[$queryName]
        try { $target.Sheet.ListObjects.Item($target.Table).Delete() } catch { }
        $target.Sheet.Cells.ClearContents()
        $listObject = $target.Sheet.ListObjects.Add(0, ($connectionTemplate -f $queryName), $null, 1, $target.Sheet.Range('A1'))
        $listObject.Name = $target.Table
        $listObject.QueryTable.CommandType = 2
        $listObject.QueryTable.CommandText = "SELECT * FROM [$queryName]"
        $listObject.QueryTable.BackgroundQuery = $false
        # The reporting PC has a different local OneDrive root.  Do not refresh
        # merely by opening the delivered workbook before that root is reviewed.
        $listObject.QueryTable.RefreshOnFileOpen = $false
        if(-not $listObject.QueryTable.Refresh($false)) { throw "Excel refresh failed for query '$queryName'." }
    }

    foreach($saved in $formulaSnapshot) { $workbook.Worksheets.Item($saved.Sheet).Range($saved.Address).Formula2 = $saved.Formula }
    $restoredFormulaCount = 0
    foreach($sheet in @($workbook.Worksheets)) {
        try { $restoredFormulaCount += $sheet.UsedRange.SpecialCells(-4123).Count } catch { }
    }
    if($restoredFormulaCount -ne $formulaSnapshot.Count) { throw "Workbook formula count changed from $($formulaSnapshot.Count) to $restoredFormulaCount." }

    if($ResetRootToPlaceholder) { $setupSheet.Range('B4').Value2 = 'C:\CHANGE_ME\OneDrive' }
    $workbook.Save()
    $workbookSaved = $true
} finally {
    if($workbook) { $workbook.Close($false) }
    $excel.Quit()
    if($workbook) { [Runtime.InteropServices.Marshal]::FinalReleaseComObject($workbook) | Out-Null }
    [Runtime.InteropServices.Marshal]::FinalReleaseComObject($excel) | Out-Null
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
    if($excelProcessId -gt 0) {
        $excelProcess = Get-Process -Id $excelProcessId -ErrorAction SilentlyContinue
        if($excelProcess) {
            $excelProcess.WaitForExit(2000) | Out-Null
            if(-not $excelProcess.HasExited) { Stop-Process -Id $excelProcessId -Force }
        }
    }
}

if($workbookSaved) { Remove-WorkbookAbsolutePathMetadata -Path $resolvedWorkbook }

# SIG # Begin signature block
# MIIHYAYJKoZIhvcNAQcCoIIHUTCCB00CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCyrMUzTPvPbEaw
# fmIBfYutWZ5EJNCsVBSnjxeFU7wOEKCCBEUwggRBMIICqaADAgECAhBw3+fRlCq+
# uUIlH/KQwoSNMA0GCSqGSIb3DQEBCwUAMCsxKTAnBgNVBAMMIEFtYXJUcmFkaW5n
# IFRlc3QgUm9vdCAyMDI2LTA5LTEzMB4XDTI2MDkxMzIwMzYzOVoXDTI3MDkxMzIw
# NDYzOFowJTEjMCEGA1UEAwwaQW1hclRyYWRpbmcgVGVzdCBQdWJsaXNoZXIwggGi
# MA0GCSqGSIb3DQEBAQUAA4IBjwAwggGKAoIBgQCzlDHdYjciWmJlVk+qaO0AKOWR
# ptpN7jDDP4xTVYk+sZsX3iJv3nSrxPyV8xqxHOQbyz82DCDF3szFAp9OUYBiLIUx
# jLIzPFCx+w2VYN9OmjtpgB16JUkOF6rg01ifm4ChZaVkRPTBQw/u3bZaM00LxiRg
# XBTiCVDYqg1FTep5AStzgxLImhb8IehyKTSxSWj/9+02ISbZzZQ+fGgJrf9BnKDL
# 4xrdxT37W2jwVutsr7mWa70SU47vK4+T0D5p4pVKZE1K8ORp/cwFrNCrtArouJ6a
# eJF5ywcbugaxayWzOkHPNZegynI0ENnDpCkGBJTEhLDXdMpxtxCSX2Fa/2YShKMd
# vbn2yXmJlZY4iDCbu97tB36xtdH3ChfPwgQP0yVH6HBjhCR2qjkXTvpu3rxH0hRN
# Ny1hgzsN24HhfGqY/UKdlP2wfU9Fnnoq55HZzHz4hGvOdEa+R1X9dJMG8ZE/Biki
# twL+Cq2oUM1dteR1WaFV59fUIgNlmWhZjeAb+D0CAwEAAaNnMGUwDgYDVR0PAQH/
# BAQDAgeAMBMGA1UdJQQMMAoGCCsGAQUFBwMDMB8GA1UdIwQYMBaAFDZt/TgYFsoB
# IkAP0dhOyE/nwN5ZMB0GA1UdDgQWBBSNa1yu9mqNiT9QIePEjr59vlN/ETANBgkq
# hkiG9w0BAQsFAAOCAYEAIvLWlo/Oi7eh4LZQOgiWcYroQJzv27q3w9fIiTUKsn2+
# Y+eKd4jCwkK70Yfh2Pxkjv4BgZ2Awg06+kigubm/2Ad3JH2UVrPAQ0NrNpc5yjLb
# YGNDUYDKShca6r6gQoS3daI8ZnyF79OapaUqXVL+u7RrGMOnShBkIccOJnSKnZdD
# yzIcmSl55cUo6nMRPGCdwCf5zEA4GuozmrBPtbIl06dPYClxn9gkmn41tAbBv37t
# ENUmzBcj05GB+9/4m1mqSnC/CFpytH1BFQ2hG0U86oVN52GUk3Si5sa/03Bjn0QH
# c0BXKN+EAoGqg4dCCUbA+HNlREDLw7uW+McuJfpuJd7cltDMpMp3p0CxNc8uelOd
# mqeJj/WOVC8uJmcYNcr+i9aBXoPV2dhY9O87G9EJJaCx5ZK7SzqbHNl/zWXdMTrs
# tudDX/6xq8Pq1mcfrvAahzHNHaQcdwvPgxJK1hQKOFXJuWjbWujab9YLd1G8eeNw
# 63yHxso9W3q0AVa+daUTMYICcTCCAm0CAQEwPzArMSkwJwYDVQQDDCBBbWFyVHJh
# ZGluZyBUZXN0IFJvb3QgMjAyNi0wOS0xMwIQcN/n0ZQqvrlCJR/ykMKEjTANBglg
# hkgBZQMEAgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3
# DQEJAzEMBgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEV
# MC8GCSqGSIb3DQEJBDEiBCA9yrTchUog15K+5Pi/QeEJyw8YS7jZHm9e2NcG8svD
# IzANBgkqhkiG9w0BAQEFAASCAYASCT2w7QBcNC9XBePnK6YnQArVOjXG0Kw5bjtX
# CF7TXgJJEdxoe2ws8blHhDTpNQT6GqzwsIooS5tGYOdWRwkGuWVU4oqGOsgXCbRW
# qNC5l46huTK/18f/hrGVlu2+TVS+JZ8vM9OkY3CyZ0/Jeh4tH5NbG0c9yg3nXRW9
# Ng7FQHBK0Up91gfok1EMl5uIoEtMBC0djqKNKj4G2O8jg6qIJ2WD0E+bHniDRURQ
# yw+0wMvgOyRfWn5kuSdRRR9wmiCFaHq1+agvSN+bexwza5p50Ftv5QcvGHXrhyFp
# 06gB//pVn+b3t7tdzihe+mJIua2qls74d8IVZs1otCw5G8vUcZJKqXHdTQo+8GlL
# Ik0vNvuAeZhlm80cJ6v5owk8rp8K/8jZWxJbFnC7AGHDlQ3bEkvn64GJ+z7q5TvS
# v5Uqdlxfbp4h8I3HK0m5SqZXLrNF6aaaavdBtdZMhepcyeCsIsWsYRypcu8r6chi
# BdJ/Toq8AeyP4FJCjZnDhDi54Pg=
# SIG # End signature block
