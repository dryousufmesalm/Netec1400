[CmdletBinding(SupportsShouldProcess)]
param(
    [string]$ConfigPath,
    [string]$RuntimeRoot,
    [datetime]$DailyTime = ((Get-Date).AddMinutes(1)),
    [ValidateRange(1,1440)][int]$SyncIntervalMinutes = 5,
    [string]$TaskName = 'MoneyMachine-Baskets-To-OneDrive',
    [switch]$AsLibrary
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$ScriptRoot = Split-Path -Parent $PSCommandPath
if([string]::IsNullOrWhiteSpace($ScriptRoot)) { throw 'Could not resolve the installer directory.' }
if([string]::IsNullOrWhiteSpace($ConfigPath)) { $ConfigPath = Join-Path $ScriptRoot 'accounts.csv' }

function Assert-BasketsSyncTaskPrerequisites {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$PowerShellPath)

    if(-not (Test-Path -LiteralPath $PowerShellPath -PathType Leaf)) { throw "Windows PowerShell 5.1 was not found: $PowerShellPath" }
    $requiredCommands = @(
        'New-ScheduledTaskAction','New-ScheduledTaskTrigger','New-ScheduledTaskPrincipal',
        'New-ScheduledTaskSettingsSet','Register-ScheduledTask'
    )
    foreach($command in $requiredCommands) {
        if(-not (Get-Command $command -ErrorAction SilentlyContinue)) { throw "Required ScheduledTasks command is unavailable: $command" }
    }
}

function Get-BasketsSyncTaskDefinition {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$ResolvedConfig,
        [Parameter(Mandatory)][string]$SyncScript,
        [Parameter(Mandatory)][string]$PowerShellPath,
        [Parameter(Mandatory)][string]$WorkingDirectory,
        [datetime]$DailyTime = ((Get-Date).AddMinutes(1)),
        [ValidateRange(1,1440)][int]$SyncIntervalMinutes = 5,
        [Parameter(Mandatory)][string]$TaskName,
        [Parameter(Mandatory)][string]$PrincipalUser
    )

    foreach($path in @($ResolvedConfig,$SyncScript,$PowerShellPath,$WorkingDirectory)) {
        if(-not [IO.Path]::IsPathRooted($path)) { throw "Task definition path is not absolute: $path" }
    }
    if([string]::IsNullOrWhiteSpace($PrincipalUser)) { throw 'Task principal user is required.' }

    if([string]::IsNullOrWhiteSpace($RuntimeRoot)) { $RuntimeRoot = Split-Path -Parent $ResolvedConfig }
    $baseArguments = '-NoProfile -NonInteractive -ExecutionPolicy Bypass -File "{0}" -ConfigPath "{1}" -RuntimeRoot "{2}"' -f $SyncScript,$ResolvedConfig,$RuntimeRoot
    $dailyAction = New-ScheduledTaskAction -Execute $PowerShellPath -Argument $baseArguments -WorkingDirectory $WorkingDirectory
    $catchupAction = New-ScheduledTaskAction -Execute $PowerShellPath -Argument "$baseArguments -StartupCatchup" -WorkingDirectory $WorkingDirectory
    $dailyTrigger = New-ScheduledTaskTrigger -Daily -At $DailyTime
    $repetition = New-CimInstance -ClassName MSFT_TaskRepetitionPattern -Namespace 'Root/Microsoft/Windows/TaskScheduler' -ClientOnly -Property @{
        Interval = [Xml.XmlConvert]::ToString([TimeSpan]::FromMinutes($SyncIntervalMinutes))
        Duration = 'P1D'
        StopAtDurationEnd = $false
    }
    $dailyTrigger.Repetition = $repetition
    return [pscustomobject]@{
        TaskName = $TaskName
        DailyAction = $dailyAction
        CatchupAction = $catchupAction
        DailyTrigger = $dailyTrigger
        LogonTrigger = New-ScheduledTaskTrigger -AtLogOn
        Principal = New-ScheduledTaskPrincipal -UserId $PrincipalUser -LogonType Interactive -RunLevel Limited
        Settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -MultipleInstances IgnoreNew -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 5) -ExecutionTimeLimit (New-TimeSpan -Minutes 15)
    }
}

if(-not $AsLibrary) {
    if(-not (Test-Path -LiteralPath $ConfigPath -PathType Leaf)) { throw "Configuration file not found: $ConfigPath" }
    $syncScript = (Resolve-Path -LiteralPath (Join-Path $ScriptRoot 'Sync-BasketsToOneDrive.ps1')).Path
    $resolvedConfig = (Resolve-Path -LiteralPath $ConfigPath).Path
    $powershell = Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $workingDirectory = Split-Path -Parent $syncScript
    $principalUser = (& whoami).Trim()

    Assert-BasketsSyncTaskPrerequisites -PowerShellPath $powershell
    $definition = Get-BasketsSyncTaskDefinition -ResolvedConfig $resolvedConfig -SyncScript $syncScript -PowerShellPath $powershell -WorkingDirectory $workingDirectory -DailyTime $DailyTime -SyncIntervalMinutes $SyncIntervalMinutes -TaskName $TaskName -PrincipalUser $principalUser

    if($PSCmdlet.ShouldProcess($TaskName, 'Register or replace scheduled CSV synchronization tasks')) {
        Register-ScheduledTask -TaskName "$TaskName-Daily" -Action $definition.DailyAction -Trigger $definition.DailyTrigger -Principal $definition.Principal -Settings $definition.Settings -Force -ErrorAction Stop | Out-Null
        Register-ScheduledTask -TaskName "$TaskName-StartupCatchup" -Action $definition.CatchupAction -Trigger $definition.LogonTrigger -Principal $definition.Principal -Settings $definition.Settings -Force -ErrorAction Stop | Out-Null
        Write-Host "Installed scheduled tasks '$TaskName-Daily' (every $SyncIntervalMinutes minutes) and '$TaskName-StartupCatchup'."
    }
}

# SIG # Begin signature block
# MIIHYAYJKoZIhvcNAQcCoIIHUTCCB00CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCD3o1dp8EEwLA24
# qsa/x2hgWM94nGN2lT7b62yOcrSd0KCCBEUwggRBMIICqaADAgECAhBw3+fRlCq+
# uUIlH/KQwoSNMA0GCSqGSIb3DQEBCwUAMCsxKTAnBgNVBAMMIEFtYXJUcmFkaW5n
# IFRlc3QgUm9vdCAyMDI2LTA5LTEzMB4XDTI2MDkxMzIwMzYzOVoXDTI3MDkxMzIw
# NDYzOFowJTEjMCEGA1UEAwwaQW1hclRyYWRpbmcgVGVzdCBQdWJsaXNoZXIwggGi
# MA0GCSqGSIb3DQEBAQUAA4IBjwAwggGKAoIBgQCzlDHdYjciWmJlVk+qaO0AKOWR
# ptpN7jDDP4xTVYk+sZsX3iJv3nSrxPyV8xqxHOQbyz82DCDF3szFAp9OUYBiLIUx
# jLIzPFCx+w2VYN9OmjtpgB16JUkOF6rg01ifm4ChZaVkRPTBQw/u3bZaM00LxiRg
# XBTiCVDYqg1FTep5AStzgxLImhb8IehyKTSxSWj/9+02ISbZzZQ+fGgJrf9BnKDL
# 4xrdxT37W2jwVutsr7mWa70SU47vK4+T0D5p4pVKZE1K8ORp/cwFrNCrtArouJ6a
# eJF5ywcbugaxayWzOkHPNZegynI0ENnDpCkGBJTEhLDXdMpxtxCSX2Fa/2YShKMd
# vbn2yXmJlZY4iDCbu97tB36xtdH3ChfPwgQP0yVH6HBjhCR2qjkXTvpu3rxH0hRN
# Ny1hgzsN24HhfGqY/UKdlP2wfU9Fnnoq55HZzHz4hGvOdEa+R1X9dJMG8ZE/Biki
# twL+Cq2oUM1dteR1WaFV59fUIgNlmWhZjeAb+D0CAwEAAaNnMGUwDgYDVR0PAQH/
# BAQDAgeAMBMGA1UdJQQMMAoGCCsGAQUFBwMDMB8GA1UdIwQYMBaAFDZt/TgYFsoB
# IkAP0dhOyE/nwN5ZMB0GA1UdDgQWBBSNa1yu9mqNiT9QIePEjr59vlN/ETANBgkq
# hkiG9w0BAQsFAAOCAYEAIvLWlo/Oi7eh4LZQOgiWcYroQJzv27q3w9fIiTUKsn2+
# Y+eKd4jCwkK70Yfh2Pxkjv4BgZ2Awg06+kigubm/2Ad3JH2UVrPAQ0NrNpc5yjLb
# YGNDUYDKShca6r6gQoS3daI8ZnyF79OapaUqXVL+u7RrGMOnShBkIccOJnSKnZdD
# yzIcmSl55cUo6nMRPGCdwCf5zEA4GuozmrBPtbIl06dPYClxn9gkmn41tAbBv37t
# ENUmzBcj05GB+9/4m1mqSnC/CFpytH1BFQ2hG0U86oVN52GUk3Si5sa/03Bjn0QH
# c0BXKN+EAoGqg4dCCUbA+HNlREDLw7uW+McuJfpuJd7cltDMpMp3p0CxNc8uelOd
# mqeJj/WOVC8uJmcYNcr+i9aBXoPV2dhY9O87G9EJJaCx5ZK7SzqbHNl/zWXdMTrs
# tudDX/6xq8Pq1mcfrvAahzHNHaQcdwvPgxJK1hQKOFXJuWjbWujab9YLd1G8eeNw
# 63yHxso9W3q0AVa+daUTMYICcTCCAm0CAQEwPzArMSkwJwYDVQQDDCBBbWFyVHJh
# ZGluZyBUZXN0IFJvb3QgMjAyNi0wOS0xMwIQcN/n0ZQqvrlCJR/ykMKEjTANBglg
# hkgBZQMEAgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3
# DQEJAzEMBgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEV
# MC8GCSqGSIb3DQEJBDEiBCBXl4bTiy6HdX7nvsQkF1j1mGiQAF52KW+S1Xkr0iZc
# fDANBgkqhkiG9w0BAQEFAASCAYCKEXUv12qZhtA/maTfijV2+LJpM4WO6VSDlDS9
# uMIZhiO6b0u6FFjep89pXWMiek7ZFFAvg5EzlAU8Hpylr8eG39/cf3JoxoFNgF9U
# 3zPB6hG2/i4pXT3KZx2449mfoTNPpItN9IVBInnugQBvseIpdaZyP2yCtblwL5gP
# tzWO/R2vGzfyIgHS24hkrNgriFrrj8Kfp2OSp3tGuAOpL85ON/WeDXQiimw1p0Cp
# TYpBsUNV3bCsR7uVfNstVxKH14bTcVAA24PlydFjYx5HdsJtKUQPLsHe+U8Ux9Lk
# ljpG4tnEvC/V+n61sjKrD2Iv9sokbykC9WJ42PA7iBLCMf9OMx1JQI2jNB2qtvtt
# PPioWRYW63W5bL1nRbQn2OxGp0WbAIm0H2Jd4ETzgC6Njo0t/3koX4xWyDqQ1RZY
# y3KoMYFhkBjwm0/Zl+VKZGXVl0U3Ny0ql+WDU6ucz8B0f0gCeuNu+kIw5ucrqEL8
# epMtUv5KXP5NnVWXn5TGBLXsFGc=
# SIG # End signature block
